# Shurly - UX/UI Design Brief
**Proyecto:** Diseño de identidad de marca y experiencia de usuario  
**Cliente:** Griddo / Daniel Serrano  
**Fecha:** Noviembre 2025  
**Versión:** 1.0

---

## 1. Contexto del Proyecto

### 1.1 Qué es Shurly

Shurly es un **acortador de URLs B2B** destinado a equipos de marketing de pequeñas y medianas empresas. A diferencia de los competidores, Shurly está construido con tecnología moderna (FastAPI, Astro, PostgreSQL) sobre infraestructura serverless, lo que permite ofrecer un **precio muy competitivo** sin sacrificar rendimiento.

**Naming:** 
- Acrónimo de **SH**ort + **URL** + **Y**
- Fonéticamente remite a "Sure!" → confianza, seguridad de que el trabajo se va a completar
- El sufijo "-ly" es reconocible en la categoría gracias al éxito histórico de bit.ly

### 1.2 Propuesta de Valor

> "Acortador de URLs profesional, moderno y accesible que permite a equipos de marketing de PYMEs rastrear y gestionar sus enlaces con la simplicidad de usar una herramienta amigable y la potencia de un servicio empresarial."

**Diferenciadores clave:**
1. **Gestión de campañas avanzada** - Creación masiva de URLs personalizadas vía CSV con datos de usuario flexibles
2. **Precio competitivo** - Infraestructura serverless moderna permite costos operativos muy bajos
3. **Experiencia de usuario excepcional** - Foco en simplicidad, progressive disclosure y microinteracciones cuidadas
4. **Stack moderno** - FastAPI + Astro + PostgreSQL (vs PHP antiguo de competidores)

### 1.3 Mercado Objetivo

**Segmento primario:** Equipos de marketing de PYMEs (1-15 personas)
- **Tamaño de equipo:** 1-2 personas típicamente, hasta 10-15 en consultoras/agencias pequeñas
- **Nivel técnico:** Usuarios digitalizados pero NO power users - necesitan interfaces guiadas
- **Caso de uso principal:** Compartir documentos (fichas técnicas, propuestas, presentaciones) almacenados en la nube con diferentes clientes, necesitando trazabilidad individual
- **Frecuencia de uso:** 2-3 interacciones semanales con el producto

**Escenarios de uso frecuentes:**
1. Crear enlace corto para documento en Google Drive/Dropbox para compartir con cliente específico
2. Generar 50+ enlaces personalizados para una campaña de email marketing (CSV bulk)
3. Revisar analíticas de qué clientes han abierto la propuesta enviada
4. Organizar enlaces por proyecto/cliente usando tags

---

## 2. Objetivos del Proyecto

### 2.1 Objetivos de Negocio

1. **Diferenciación competitiva** - Destacar en un mercado saturado mediante experiencia de usuario superior
2. **Conversión freemium → Pro** - Diseño que facilite el upgrade cuando usuarios necesiten features premium
3. **Onboarding sin fricción** - Reducir abandono en First Time Experience (FTE)
4. **Retención** - Diseño que invite a volver y usar el producto regularmente

### 2.2 Objetivos de Diseño

1. **Identidad de marca memorable** que comunique profesionalidad con personalidad (referencia: Justin Long en campaña "Get a Mac" de Apple 2006-2009)
2. **Interfaz limpia y minimalista** que no abrume - evitar el error de Rebrandly (demasiado cargado)
3. **First Time Experience excepcional** - "Just works" sin necesidad de tutoriales
4. **Microinteracciones y feedback visual** que refuercen la confianza en cada acción
5. **Progressive disclosure** - Mostrar complejidad gradualmente solo cuando se necesita

### 2.3 Principios de Diseño (Core Values)

**1. Simplicidad Radical**
- La acción principal debe ser obvia en cada pantalla
- Zero cognitive load para tareas frecuentes
- Ocultar complejidad avanzada tras accordions/toggles

**2. Confianza Activa**
- Cada acción debe tener feedback visual/animado inmediato
- Estados de loading, success y error siempre visibles
- Nunca dejar al usuario preguntándose "¿funcionó?"

**3. Progressive Disclosure**
- Mostrar lo esencial primero, lo avanzado bajo demanda
- Features avanzadas no deben intimidar a nuevos usuarios
- Usuarios pro deben poder acceder a todo rápidamente

**4. Personalidad Profesional**
- Tono desenfadado pero competente (Justin Long en "Get a Mac")
- Copy amigable sin ser infantil
- Detalles cuidados sin sobrecarga visual

---

## 3. Análisis Competitivo

### 3.1 Competidores Analizados

| Competidor | Fortaleza | Debilidad | Aprendizaje para Shurly |
|------------|-----------|-----------|-------------------------|
| **Rebrandly** | API completa, features enterprise | UI sobrecargada, demasiadas opciones en primer plano | Ocultar complejidad avanzada |
| **bit.ly** | Reconocimiento de marca, UX sólida | Stack antiguo, pricing alto | Referencia de simplicidad |
| **YOURLs** | Open-source, flexible | UI anticuada, confusa (búsqueda vs creación mezcladas) | Separar claramente acciones primarias |
| **Campaigntrackly** | Foco en campañas | Nicho muy específico, poco conocido | Validación de nuestro enfoque en campañas |
| **bl.ink** | Features empresariales | Complejo, orientado a grandes organizaciones | No ir por ese camino |

### 3.2 Insights Críticos del Benchmarking

**De análisis funcional:**
1. ✅ Shurly tiene ventaja en **gestión de campañas** (bulk CSV, datos flexibles JSONB)
2. 🔴 **Gaps críticos identificados:**
   - Open Graph metadata (crítico para compartir en redes sociales)
   - Sistema de TAGS (organización y búsqueda)
   - Edición de URLs existentes (actualmente solo delete + recreate)
   - QR codes (table stakes en 2025)
   - Notificaciones (diferenciador valioso)

**De análisis UX (observaciones):**
- **YOURLs:** Confunde creación con búsqueda - evitar este antipatrón
- **YOURLs:** No permite múltiples short URLs para misma destination - nuestro caso de uso principal requiere esto ✅
- **Rebrandly:** Excelente Link Preview Card pero demasiada info en dashboard - balance necesario
- **Rebrandly:** Buen uso de badges para estado (forward params, tipo URL) - aplicar este patrón

---

## 4. Alcance del Proyecto

### 4.1 Entregables Fase 1: Estrategia e Identidad

**4.1.1 Investigación Competitiva UX (1 semana)**
- Análisis heurístico de 5 competidores principales (Rebrandly, bit.ly, YOURLs, Campaigntrackly, bl.ink)
- Evaluación de:
  - Arquitectura de información
  - Patrones de interacción
  - Jerarquía visual
  - Flujos de onboarding
  - Micro-interacciones destacables
  - Pain points detectados
- Documento con findings y recomendaciones

**4.1.2 Identidad Visual (2 semanas)**
- Propuesta de naming visual (logotipo/wordmark)
- Paleta de color primaria y extendida
- Tipografía (headings, body, code/mono)
- Sistema de iconografía
- Guía de tono y voz
- Mood board y referencias visuales
- Brand guidelines documento (15-20 páginas)

**Deliverables:**
- [ ] Documento de análisis competitivo UX (PDF, 25-30 páginas)
- [ ] Logotipo en versiones: horizontal, vertical, isotipo, monocromo
- [ ] Paleta de colores con códigos HEX/RGB/HSL
- [ ] Especificación tipográfica con pairings
- [ ] Guía de identidad visual (PDF, 15-20 páginas)
- [ ] Assets exportados (SVG, PNG en múltiples resoluciones)

---

### 4.2 Entregables Fase 2: Sistema de Diseño (2 semanas)

**4.2.1 Design Tokens**
- Variables de color (primary, secondary, success, warning, error, neutral scales)
- Sistema de espaciado (4px, 8px, 12px, 16px, 24px, 32px, 48px, 64px)
- Escala tipográfica (display, h1-h6, body, small, caption)
- Shadows y elevaciones (4 niveles)
- Border radius (none, sm, md, lg, full)
- Transiciones y duraciones

**4.2.2 Componentes Base**
- Buttons (primary, secondary, tertiary, danger, ghost, icon)
- Inputs (text, email, URL, password, textarea)
- Toggles y checkboxes
- Badges y pills
- Cards (default, hover, selected, disabled)
- Modals y overlays
- Empty states
- Loading states (spinner, skeleton)
- Success/error states
- Tooltips
- Dropdowns y selects
- Navigation (navbar, tabs)

**4.2.3 Componentes Específicos de Shurly**
- URLCard (elemento de lista de URLs)
  - Con title prominente
  - Badge de tipo (standard/custom/campaign)
  - Badge de forward_parameters (ON/OFF)
  - Timestamp relativo (last_click_at)
  - Click count
  - Botones de acción (copy, edit, delete, view details)
- Link Preview Card (Open Graph)
  - OG image display (1200x630)
  - OG title
  - OG description
  - Edit/refresh buttons
- Campaign Card
- Stats Cards (métricas resumidas)
- Tag Pills (color-coded, autocomplete)

**Deliverables:**
- [ ] Design System documentado en Figma
- [ ] Biblioteca de componentes (Figma)
- [ ] Especificaciones para Tailwind v4 custom config
- [ ] Guía de uso de componentes (interacciones, estados, variantes)

---

### 4.3 Entregables Fase 3: Diseño de Pantallas (3-4 semanas)

#### **4.3.1 Pantallas Públicas (shur.ly)**

**Landing Page (`/`)**
- Hero section con mensaje principal (TBD tras investigación)
- Value propositions (3-4 bloques)
- Social proof (si aplicable: "Trusted by X companies")
- Pricing cards (Free vs Pro)
- CTA dual (Sign Up / Sign In)
- Footer

**Consideraciones:**
- Objetivo: Educar primero, luego convertir
- Screenshots/video del producto (no demo interactivo en v1)
- Mensaje hero debe salir de la investigación de diseño
- Tono: profesional con personalidad (Justin Long vibe)

#### **4.3.2 Autenticación**

**Registro (`/register`)**
- Simplicidad extrema: solo email + password
- Sin campos adicionales (nombre, empresa, etc.) - reducir fricción
- Validación inline
- Estado de loading claro
- Auto-login tras registro exitoso

**Login (`/login`)**
- Email + password
- Link a "Forgot password" (aunque no hay email aún - mencionar en roadmap)
- Auto-redirect a dashboard

**FTE (First Time Experience):**
- NO onboarding interactivo con tooltips/tour
- Principio: "Just works" - interfaz autoexplicativa
- Considerar: crear URL de ejemplo automáticamente tras registro
- Progressive disclosure: complejidad se revela al usarse

#### **4.3.3 Dashboard Principal (`/dashboard`)**

**Elementos:**
- Navbar top (logo, user email, logout)
- Tabs/navegación secundaria (URLs, Campaigns, Analytics, Settings)
- CTA prominente: "Create New URL" (botón primary grande)
- Stats overview (3 cards): Total URLs, Total Clicks, Active Campaigns
- Lista de URLs (URLCard components)
  - **Prioridad de información:**
    1. Title (grande, bold) - ⚠️ Nuevo campo, actualmente falta en UI
    2. Short URL (con botón copy)
    3. Original URL (truncada si es larga)
    4. Metadata row: Type badge | Forward params badge | Last click (relativo: "2h ago") | Click count
    5. Action buttons: View Details | Edit | Delete
- Paginación (si >50 URLs)
- Empty state (primera vez, sin URLs creadas aún)

**Interacciones clave:**
- Hover en URLCard → sombra elevada, acción buttons visible
- Click en copy → feedback visual + toast "Copied!"
- Click en short URL → abre en nueva tab
- Click en "Edit" → modal overlay (ver 4.3.7)

**Estados:**
- Loading (skeleton cards)
- Empty (primera vez)
- Con datos (1-50+ URLs)

#### **4.3.4 Crear URL (`/dashboard/create`)**

**Layout:** Dos columnas desktop, stack mobile
- **Columna izquierda: Formulario**
  - Toggle: Standard / Custom
  - Input: Original URL (validación inline HTTP/HTTPS)
  - Input: Title (opcional, nuevo campo) - placeholder: "My client proposal"
  - Toggle: Forward query parameters (default: ON)
  - Accordion: "Social Media Preview (Advanced)" - Open Graph fields
    - OG Title (auto-fetch button)
    - OG Description (auto-fetch button)
    - OG Image URL (auto-fetch button)
    - Preview button → ver columna derecha
  - Accordion: "Tags" (color-coded, autocomplete)
    - Presets: Campaign, Project, Client, Internal
    - User-generated tags
    - Sugerir AI-powered tag suggestion
  - Submit button (primary)

- **Columna derecha: Live Preview**
  - Visual preview de Short URL
  - Si OG fields completados → preview card estilo Twitter/LinkedIn
  - Stats esperadas (estimación basada en histórico)

**Features faltantes en UI actual (incluir en diseño):**
- ✅ Title field ya existe en backend
- ✅ Forward parameters toggle ya existe en backend  
- ✅ OG fields ya existen en backend
- ❌ Tags system (pendiente backend + UI) - diseñar ahora
- ❌ Live preview visual (solo texto actualmente) - diseñar
- ❌ Auto-fetch OG metadata (backend preparado, falta trigger UI) - diseñar botón

**Success state:**
- Card verde con short URL generada
- Botón copy primary
- Botones secundarios: "Create Another" | "View Details" | "Back to Dashboard"

#### **4.3.5 Detalles de URL (`/dashboard/urls/[short_code]`)**

**Layout:** Single column con secciones claras

1. **Header**
   - Title (h1, prominente) - ⚠️ Nuevo campo
   - Short code (con botón copy)
   - Badges: Type | Forward params status
   - Original URL (clickable, nueva tab)
   - Metadata: Created | Last click (relativo) | Updated
   - Action buttons: Edit | Delete | Refresh OG

2. **Link Preview Card** (si tiene OG metadata) - ⚠️ Nuevo componente
   - OG image (1200x630, cropped)
   - OG title
   - OG description
   - Edit button → modal overlay
   - Refresh button → re-fetch OG from destination URL
   - Timestamp: "Preview last updated 2 days ago"

3. **Stats Cards** (row de 4 cards)
   - Total clicks
   - Unique visitors
   - Clicks (7 days)
   - CTR (si aplicable)

4. **Click Activity Chart**
   - Bar chart 7 días
   - Tooltips interactivos

5. **Geographic Distribution**
   - Horizontal bars por país (top 5-10)
   - Opción "View all" → expandir

6. **Campaign Info** (si url_type === 'campaign')
   - Link a campaign parent
   - User data tags asociados

7. **Tags** (si existen)
   - Pills color-coded
   - Click → filter by tag

**Features faltantes en UI actual (incluir en diseño):**
- ❌ Link Preview Card completo
- ❌ Edit button + modal
- ❌ Refresh OG button + loading state
- ❌ Title en header
- ❌ Last click timestamp
- ❌ Forward params badge
- ❌ Tags display

#### **4.3.6 Campañas**

**Lista de Campañas (`/dashboard/campaigns`)**
- CTA: "New Campaign"
- Campaign cards:
  - Name (h3)
  - Destination URL
  - Stats: X URLs | Y total clicks | Created date
  - Tags (si existen)
  - Actions: View Details | Export CSV | Delete

**Crear Campaña (`/dashboard/campaigns/create`)**
- Wizard multi-step (4 pasos):
  1. Name + Destination URL
  2. Upload CSV (drag & drop + file picker)
  3. Preview & validate (mostrar primeras 5 filas)
  4. Confirm & create (loading state)
- Feedback claro en cada paso

**Detalles de Campaña (`/dashboard/campaigns/[id]`)**
- Similar a URL details pero con:
  - Tabla de URLs generadas (paginada si >50)
  - User data columns visibles
  - Bulk actions (select all → copy URLs)
  - Export CSV button

#### **4.3.7 Modales y Overlays**

**Edit URL Modal**
- Overlay oscuro (backdrop)
- Card centrado (max-width: 600px)
- Campos editables:
  - Title
  - Destination URL
  - Forward parameters toggle
  - OG Title
  - OG Description
  - OG Image URL
- Botones: Save | Cancel
- Loading state al guardar
- Success feedback (cerrar modal + toast)

**Delete Confirmation Modal**
- Texto: "Are you sure you want to delete this URL?"
- Warning: "This action cannot be undone. XX clicks will lose tracking."
- Botones: Delete (danger) | Cancel
- Si es campaign URL → bloquear delete, sugerir delete campaign

**Tag Management Modal** (si no inline)
- Crear nuevo tag
- Color picker
- List de tags existentes
- Edit/delete tags

#### **4.3.8 Analytics (`/dashboard/analytics`)**

**Overview:**
- Date range selector (7d, 30d, 90d, custom)
- Cards: Total clicks, Unique visitors, Top performing URL, Geographic reach
- Timeline chart (clicks over time)
- Top 10 URLs table
- Geographic map (simple, sin libraries complejas)

**Consideraciones:**
- En Free tier: "Upgrade to Pro for advanced analytics"
- Pro features: Custom date ranges, export data, real-time stats

#### **4.3.9 Settings (`/dashboard/settings`)**

**Tabs:**
1. **Account**
   - Email (read-only)
   - Change password
   - API key generation (Phase 3.5 ya implementada)
   - Danger zone: Delete account

2. **Notifications** (diseñar, implementar en Phase 2)
   - Toggle: Enable notifications
   - Channels: Slack, Google Chat, Telegram, WhatsApp (config)
   - Batch settings:
     - First hour: All clicks trigger notification
     - After 1 hour: Batch by hour
     - After 1 week: Batch by day
   - Test notification button

3. **Billing** (si aplica Pro tier)
   - Current plan (Free / Pro)
   - Usage stats vs limits
   - Upgrade/downgrade buttons
   - Payment method

---

### 4.4 Interacciones y Microanimaciones

**Especificar para cada componente:**
- Hover states (color shift, shadow elevation)
- Active/pressed states
- Loading spinners (branded, no generic)
- Skeleton loading para listas
- Toast notifications (success, error, info)
  - Posición: top-right
  - Duración: 3-5 segundos
  - Animación: slide-in from right + fade out
- Copy feedback:
  - Button state change: "Copy" → "Copied!" con checkmark icon
  - Duración: 2 segundos
  - Color shift a success green
- Modal animations:
  - Fade in backdrop (150ms)
  - Scale + fade in card (200ms, ease-out)
  - Reverse on close
- Accordion chevron rotation (150ms)
- Chart hover tooltips

**Principio:** Todas las animaciones deben reforzar la acción, nunca retrasar.

---

### 4.5 Estados de la Aplicación

Diseñar para cada pantalla principal:

1. **Empty State**
   - Ilustración/icono central
   - Headline corto
   - Copy explicativo (1-2 líneas)
   - CTA prominente

2. **Loading State**
   - Skeleton cards (preferido sobre spinners para listas)
   - Spinner para acciones puntuales
   - Progress bar para uploads

3. **Error State**
   - Icono/ilustración de error (no alarmante)
   - Mensaje claro y accionable
   - Botón "Try again" o "Go back"

4. **Success State**
   - Checkmark icon
   - Mensaje positivo
   - Siguiente acción sugerida

5. **Paywall State** (Free → Pro upgrade prompts)
   - Badge "Pro Feature"
   - Copy: "Upgrade to unlock [feature]"
   - Botón "See Plans"
   - No bloquear completamente la UI, solo deshabilitar feature

---

### 4.6 Responsive Design

**Breakpoints (Tailwind defaults):**
- sm: 640px
- md: 768px
- lg: 1024px
- xl: 1280px
- 2xl: 1536px

**Estrategia:** Desktop-first con adaptación mobile (no se espera alto uso mobile)

**Mobile (< 768px):**
- Navbar → hamburger menu
- Stats cards stack (1 col)
- URL cards stack (1 col)
- Formularios single column
- Tablas → scroll horizontal o cards
- Modales ocupan casi full screen

**Tablet (768-1024px):**
- 2 columnas para cards
- Formularios pueden mantener 2 columnas

**Desktop (>1024px):**
- Layout completo con sidebars si aplica
- 3-4 columnas para cards
- Formularios en 2 columnas con preview

---

## 5. Gaps Funcionales a Diseñar (Críticos)

Estos features existen en backend pero faltan en UI, o están en roadmap inmediato:

### ✅ Ya en Backend, Faltan en UI:
1. **Title field** - Diseñar en: URLCard, URL details, Create form
2. **Last click timestamp** - Diseñar en: URLCard, URL details
3. **Forward parameters toggle** - Diseñar en: Create form, Edit modal, URL details badge
4. **Open Graph fields** - Diseñar en: Create form, Edit modal, Link Preview Card
5. **PATCH endpoint (edit URL)** - Diseñar: Edit modal completo

### ⚠️ En Roadmap, Diseñar Ahora:
6. **Tags system** - Diseñar: Tag pills, tag autocomplete, tag management, tag filtering
7. **Link Preview Card** - Diseñar: Componente completo con OG image/title/description
8. **QR Code generation** - Diseñar: Botón "Generate QR" en URL details, modal con QR display, download options (PNG/SVG)
9. **Notificaciones** (Phase 2) - Diseñar: Settings panel, notification preferences, channel config

### 🟡 Nice-to-Have (incluir en diseño si tiempo):
10. **Bulk select** - Checkbox selection en listas, bulk action bar
11. **Advanced filtering** - Filtros por type, tags, date range, click count
12. **Export data** - Botón export en analytics y campaign details

---

## 6. Restricciones y Consideraciones Técnicas

### 6.1 Stack Técnico

**Frontend:**
- **Astro** (SSG/SSR framework) - mayormente estático con islas interactivas
- **Tailwind CSS v4** - utility-first, customizable
- **TypeScript** - type-safe
- **No React/Vue global** - solo islas de interactividad donde necesario

**Implicaciones para diseño:**
- Animaciones complejas stateful limitadas (preferir CSS transitions/animations)
- Componentes reutilizables deben ser Astro components o Web Components
- Interactividad pesada (charts, drag-drop) usar librerías lightweight

### 6.2 Personalización de Tailwind

**El diseño puede y debe personalizar Tailwind v4:**
- Paleta de colores custom (más allá de defaults)
- Typography scale custom
- Spacing scale custom si necesario
- Custom components (@apply directivas)
- Plugins para componentes complejos

**Entregable requerido:** Archivo de config Tailwind sugerido basado en design tokens

### 6.3 Iconografía

**Opciones:**
- Heroicons (actual, inline SVG)
- Lucide (moderna, tree-shakeable)
- Custom icon set (si identidad lo requiere)

**Decisión del diseñador:** Proponer set de iconos coherente con identidad

### 6.4 Ilustraciones y Assets

**Necesarios:**
- Empty state illustrations (3-5 escenas)
- Error state illustrations (2-3 escenas)
- Landing page hero image/illustration
- Favicon y app icons (múltiples sizes)

**Estilo:** TBD por diseñador (opciones: flat, isométrico, 3D, line-art)

---

## 7. Modelo de Negocio y Pricing (Afecta Diseño)

### 7.1 Tiers

**Free Tier:**
- **Límite de URLs:** 50 URLs activas
- **Límite de clicks:** 1,000 clicks/mes
- **Features bloqueadas:**
  - ❌ Open Graph editing
  - ❌ Notificaciones
  - ❌ Analítica avanzada (solo basic stats)
  - ❌ Custom QR codes
  - ❌ API access
- **Features incluidas:**
  - ✅ Creación standard/custom URLs
  - ✅ Campañas básicas
  - ✅ Tags (max 10)
  - ✅ Analytics básicas (7 días)

**Pro Tier:**
- **Precio:** TBD (sugerencia: $9-19/mes)
- **Límites:**
  - URLs ilimitadas
  - Clicks ilimitados
- **All Features Unlocked:**
  - ✅ Open Graph editing
  - ✅ Notificaciones (todos los canales)
  - ✅ Analítica avanzada (custom date ranges, export)
  - ✅ QR codes custom (logo, colors)
  - ✅ API access
  - ✅ Priority support

**Consideración Open-Source:**
- Versión self-hosted (sin UI pulida, solo funcional)
- Monetización vía "Buy me a coffee" / Sponsors
- Diseño debe contemplar branding que funcione en modelo dual (SaaS + OSS)

### 7.2 Diseño de Paywall

**Principios:**
- No bloquear completamente la UI (evitar frustración)
- Mostrar preview de feature con badge "Pro"
- Copy persuasivo pero no agresivo: "Unlock with Pro" en lugar de "Upgrade Now!"
- Link claro a pricing page
- En settings: Dashboard de uso actual vs límites

**Ejemplos:**
- Botón "Generate QR" → Click → Modal "This is a Pro feature. See plans →"
- Notifications settings → Toggle deshabilitado con tooltip "Available in Pro"
- Analytics date range > 7 days → Selector deshabilitado con badge "Pro"

---

## 8. Deliverables Finales y Formatos

### 8.1 Archivos Figma

- [ ] **Main Design File**
  - Página 1: Cover + índice
  - Página 2: Brand guidelines
  - Página 3: Design system (tokens, components)
  - Página 4-15: Pantallas (Desktop)
  - Página 16-20: Pantallas (Mobile)
  - Página 21: Flows & interactions
  - Página 22: Assets & illustrations

- [ ] **Component Library** (Figma file separado)
  - Todos los componentes como components reutilizables
  - Variantes (states, sizes, types)
  - Auto-layout configurado
  - Documentation en properties panel

### 8.2 Documentación

- [ ] **Design System Spec** (Notion/PDF)
  - Design tokens table
  - Component usage guidelines
  - Do's and don'ts
  - Accessibility notes (WCAG AA compliance)

- [ ] **Interaction Spec** (Notion/PDF o Loom videos)
  - Descripción de microanimaciones
  - Durations y easing functions
  - Hover/active/loading states behavior

- [ ] **Handoff Notes** (Markdown)
  - Tailwind config sugerido
  - Custom CSS necesario
  - JavaScript behaviors requeridos
  - Assets necesarios (ilustraciones, icons)

### 8.3 Assets Exportados

- [ ] **Logos**
  - SVG (limpio, optimizado)
  - PNG (1x, 2x, 3x)
  - Monocromo y color
  - Horizontal, vertical, isotipo

- [ ] **Icons**
  - SVG sprite sheet o individuales
  - 24x24px, 48x48px

- [ ] **Ilustraciones**
  - SVG + PNG fallback
  - Light/dark mode variants si aplica

- [ ] **Favicon Pack**
  - favicon.ico
  - favicon-16x16.png
  - favicon-32x32.png
  - apple-touch-icon.png
  - android-chrome-192x192.png
  - android-chrome-512x512.png

---

## 9. Cronograma y Fases

**Timeline total:** 4 semanas máximo (flexible según carga)

### Semana 1: Investigación y Estrategia
- **Días 1-2:** Análisis heurístico de 5 competidores
- **Días 3-5:** Propuestas de identidad visual (3 direcciones)
- **Entregable:** Documento de research + 3 propuestas de identidad (mood boards)
- **Checkpoint:** Selección de dirección visual → aprobar 1 de 3

### Semana 2: Identidad y Sistema
- **Días 1-3:** Desarrollo de identidad seleccionada (logo, paleta, tipografía)
- **Días 4-5:** Design tokens + componentes base
- **Entregable:** Brand guidelines + Design system v1
- **Checkpoint:** Revisión de sistema de componentes

### Semana 3: Diseño de Pantallas (Core)
- **Días 1-2:** Landing page + Auth screens
- **Días 3-4:** Dashboard + URL list + Create URL
- **Día 5:** URL details + Edit modal
- **Entregable:** Diseños desktop de flujo principal
- **Checkpoint:** Revisión de flujo core

### Semana 4: Diseño de Pantallas (Secundarias) + Responsive
- **Días 1-2:** Campaigns screens + Analytics + Settings
- **Días 3-4:** Adaptación mobile de todas las pantallas
- **Día 5:** Documentación, specs, y handoff prep
- **Entregable final:** Figma completo + Documentación + Assets

**Checkpoints semanales:** Viernes al final de cada semana para review y ajustes

---

## 10. Criterios de Éxito

### 10.1 KPIs de Diseño (Post-Implementación)

**Onboarding:**
- ✅ Tiempo promedio desde registro hasta primera URL creada < 2 minutos
- ✅ % usuarios que crean al menos 1 URL en primera sesión > 80%
- ✅ % usuarios que regresan en primeros 7 días > 40%

**Usabilidad:**
- ✅ Tiempo promedio para crear URL estándar < 30 segundos
- ✅ Tiempo promedio para crear campaña (CSV subido) < 3 minutos
- ✅ % usuarios que completan acción sin errores > 90%

**Conversión Free → Pro:**
- ✅ % free users que interactúan con feature Pro > 30%
- ✅ % free users que visitan pricing page > 15%
- ✅ Tasa de conversión Free → Pro > 5% (en primeros 30 días)

**Satisfacción:**
- ✅ NPS > 50
- ✅ Feedback positivo sobre "facilidad de uso" en surveys > 80%

### 10.2 Checklist de Calidad de Diseño

**Antes de handoff, verificar:**
- [ ] Todas las pantallas tienen estados: default, loading, empty, error, success
- [ ] Mobile responsive para todos los breakpoints
- [ ] Componentes son consistentes (no duplicados con ligeras diferencias)
- [ ] Accessibility: Contraste WCAG AA (4.5:1 para texto normal)
- [ ] Todos los textos usan copy definitivo (no "Lorem ipsum")
- [ ] Interacciones especificadas (hover, active, disabled states)
- [ ] Spacing es consistente (múltiplos de 4px o 8px)
- [ ] No hay elementos con opacity <10% (invisibles)
- [ ] Naming de layers en Figma es claro y organizado
- [ ] Design system tiene todas las variantes necesarias

---

## 11. Preguntas Abiertas para el Diseñador

Estas preguntas deben resolverse durante el proceso de diseño:

### 11.1 Identidad Visual
1. ¿El logo debe ser wordmark solo o incluir símbolo/isotipo?
2. ¿La paleta de colores debe ser vibrante (tech startup) o sobria (enterprise)?
3. ¿Ilustraciones estilo flat, isométrico, o line-art minimalista?

### 11.2 UX Estratégica
4. ¿Hero message en landing? Opciones:
   - "Short links that work for your business"
   - "URLs that tell you who's interested"
   - "Track every click, know every client"
   - (Proponer alternativas tras research)

5. ¿Cómo gestionar Tags visualmente?
   - Color-coding automático (hash del nombre)
   - Usuario elige color manualmente
   - Paleta fija de 12 colores rotativa

6. ¿Dónde mostrar Link Preview Card?
   - Solo en URL details page
   - También en dashboard cards (colapsado)
   - También en Create URL form (preview live)

7. ¿Cómo indicar "last click" timestamp?
   - Relativo ("2 hours ago")
   - Absoluto ("Nov 9, 2:35pm")
   - Ambos (relativo en card, absoluto en hover tooltip)

8. ¿Feedback de copy URL?
   - Toast notification
   - Botón state change temporalmente
   - Ambos

### 11.3 Interacciones Avanzadas
9. ¿Auto-fetch de OG metadata?
   - Automático al pegar URL (fetching en background)
   - Manual con botón "Fetch preview"
   - Ambos: intento auto + botón manual si falla

10. ¿Gestión de errores?
    - Inline (bajo el input)
    - Toast notification
    - Modal para errores críticos
    - Combinación según severidad

---

## 12. Referencias y Recursos

### 12.1 Material de Análisis Entregado

- `FEATURE_COMPARISON.md` - Comparativa funcional Rebrandly vs Shurly
- `FUNCTIONAL_GAP_ANALYSIS.md` - Gaps vs YOURLs con priorización
- `REBRANDLY_API_ANALYSIS.md` - Análisis detallado de API y patrones de Rebrandly
- `SCREEN_INVENTORY.md` - Inventario completo de pantallas y estados actuales

### 12.2 Competidores para Análisis UX

- Rebrandly: https://rebrandly.com
- bit.ly: https://bitly.com
- YOURLs: https://yourls.org
- Campaigntrackly: https://www.campaigntrackly.com
- bl.ink: https://www.bl.ink

### 12.3 Referencias Visuales Sugeridas

**Tono y personalidad:**
- Campaña "Get a Mac" (Apple 2006-2009) - Justin Long character
- Linear (https://linear.app) - Producto SaaS con personalidad pero profesional
- Raycast (https://raycast.com) - Moderno, clean, microinteracciones cuidadas

**Design systems de referencia:**
- Vercel Design System
- Stripe Design System
- Tailwind UI components

**Ilustraciones:**
- Undraw (si se va por flat illustration)
- Storyset (si se va por isometric)
- Lukasz Adam (si se va por 3D clay style)

---

## 13. Contacto y Coordinación

**Punto de contacto:** Daniel Serrano (daniel@griddo.com)

**Metodología de trabajo:**
- Checkpoints semanales: Viernes 4pm CET (30-60 min review)
- Canal de comunicación: Slack / Email
- Entregas: Via Figma (view-only link) + assets en Google Drive
- Feedback: Anotaciones en Figma + documento de feedback consolidado

**Formato de entregas:**
- Figma link (comentarios habilitados)
- PDF exports para review offline
- Assets en carpeta Drive organizada por tipo

---

## 14. Siguientes Pasos (Después del Diseño)

Una vez completado el diseño, el flujo será:

1. **Handoff a desarrollo**
   - Figma Dev Mode
   - Specs documentadas
   - Assets exportados

2. **Implementación en fases**
   - Fase 1: Identidad + Landing page (1 semana)
   - Fase 2: Dashboard core + Create URL (2 semanas)
   - Fase 3: Features avanzadas + Campaigns (2 semanas)
   - Fase 4: Polish + animations + responsive (1 semana)

3. **Testing con usuarios**
   - 5-10 usuarios del target (equipos marketing PYMEs)
   - Tasks: Registro, crear URL, crear campaña, revisar analytics
   - Métricas: Task success rate, tiempo, frustration points

4. **Iteración post-launch**
   - Analytics de uso real
   - Heatmaps (Hotjar/similar)
   - Feedback directo de usuarios
   - Sprint de mejoras cada 2 semanas

---

## Apéndice A: Glosario Técnico

**Términos del dominio:**
- **Short code:** El identificador único de la URL corta (ej: "abc123" en shur.ly/abc123)
- **Destination URL / Original URL:** La URL larga a la que redirige el short link
- **Campaign:** Conjunto de URLs personalizadas generadas desde un CSV
- **User data:** Datos adicionales asociados a cada URL de campaña (JSONB flexible)
- **Forward parameters:** Opción para mantener query params de la URL original al redirigir
- **Open Graph (OG):** Metadata para rich previews en redes sociales
- **Click tracking:** Registro de cada redirección para analytics
- **URL type:** standard (auto-generado) | custom (user-defined) | campaign (bulk-created)

**Términos técnicos:**
- **Progressive disclosure:** Principio de diseño que muestra complejidad gradualmente
- **Skeleton loading:** Placeholder visual que imita la estructura del contenido final
- **Toast notification:** Mensaje temporal no-modal que aparece y desaparece
- **Design tokens:** Variables que definen el sistema de diseño (colors, spacing, typography)
- **WCAG AA:** Estándar de accesibilidad web (Web Content Accessibility Guidelines nivel AA)

---

## Apéndice B: Inspiración Visual (Mood Board)

*A completar por el diseñador tras research inicial.*

Espacios para incluir:
- 10-15 screenshots de referencias visuales
- Paletas de color inspiracionales
- Ejemplos de microinteracciones
- Layouts de referencia

---

## Apéndice C: Matriz de Features por Pantalla

| Feature | Landing | Dashboard | Create URL | URL Details | Campaigns | Settings |
|---------|---------|-----------|------------|-------------|-----------|----------|
| Title field | - | ✅ Display | ✅ Input | ✅ Display | ✅ Display | - |
| Tags | - | 🟡 Filter | ✅ Input | ✅ Display | 🟡 Filter | 🟡 Manage |
| OG metadata | - | - | ✅ Input | ✅ Preview Card | - | - |
| Forward params | - | ✅ Badge | ✅ Toggle | ✅ Badge | - | - |
| QR code | - | - | - | ✅ Generate | - | - |
| Last click | - | ✅ Display | - | ✅ Display | ✅ Display | - |
| Edit URL | - | 🟡 Action | - | ✅ Action | - | - |
| Notifications | - | - | - | - | - | ✅ Config |
| Analytics | - | ✅ Overview | - | ✅ Detailed | ✅ Campaign | 🟡 Usage |

**Leyenda:**
- ✅ Feature principal en esta pantalla
- 🟡 Feature secundaria en esta pantalla
- `-` No aplica

---

## Firma y Aprobación

**Brief elaborado por:** Claude (AI Assistant)  
**Revisado por:** Daniel Serrano  
**Fecha:** Noviembre 2025  
**Versión:** 1.0 - Documento ejecutable para equipo de diseño

**Estado:** ✅ Listo para iniciar fase de investigación y diseño

---

**FIN DEL BRIEF**
